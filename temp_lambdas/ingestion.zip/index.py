import json
import boto3
import os

# Inicializamos el cliente de SQS
sqs = boto3.client('sqs')
QUEUE_URL = os.environ.get('QUEUE_URL') # Ejemplo: https://sqs.us-east-1.amazonaws.com/1234567890/marketplace-orders-main

def lambda_handler(event, context):
    try:
        # 1. Extraer los datos del evento (asumiendo que vienen de una API Gateway)
        body = json.loads(event['body'])
        
        # 2. Lógica simple de validación
        print(f"Procesando orden para el producto: {body.get('producto')}")
        
        # 3. Enviar el mensaje a la cola SQS
        response = sqs.send_message(
            QueueUrl=QUEUE_URL,
            MessageBody=json.dumps(body),
            MessageAttributes={
                'eventType': {
                    'DataType': 'String',
                    'StringValue': 'order.created'
                }
            }
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Orden enviada a la cola', 'id': response['MessageId']})
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'No se pudo procesar la orden'})
        }