import boto3
import json
import os
import psycopg2 # O pymysql dependiendo de tu motor RDS
from datetime import datetime

sqs = boto3.client('sqs')
sns = boto3.client('sns')

# Variables de entorno recomendadas
DLQ_URL = os.environ['DLQ_URL']
SNS_ADMIN_TOPIC_ARN = os.environ['SNS_ADMIN_TOPIC_ARN']
DB_HOST = os.environ['DB_HOST']
DB_NAME = os.environ['DB_NAME']
DB_USER = os.environ['DB_USER']
DB_PASS = os.environ['DB_PASS']

def lambda_handler(event, context):
    messages_processed = 0
    
    try:
        # 1. Conectar a RDS
        conn = psycopg2.connect(host=DB_HOST, database=DB_NAME, user=DB_USER, password=DB_PASS)
        cur = conn.cursor()

        while True:
            # 2. Leer mensajes de la DLQ (máximo 10 a la vez)
            response = sqs.receive_message(
                QueueUrl=DLQ_URL,
                MaxNumberOfMessages=10,
                WaitTimeSeconds=1 # Short polling para revisión rápida
            )

            if 'Messages' not in response:
                break

            for msg in response['Messages']:
                msg_id = msg['MessageId']
                body = msg['Body']
                
                # 3. Registrar el error en RDS
                insert_query = "INSERT INTO error_logs (message_id, payload, created_at) VALUES (%s, %s, %s)"
                cur.execute(insert_query, (msg_id, body, datetime.now()))
                
                # 4. Notificar al Administrador por SNS
                sns.publish(
                    TopicArn=SNS_ADMIN_TOPIC_ARN,
                    Message=f"ALERTA: Mensaje fallido en DLQ.\nID: {msg_id}\nContenido: {body}",
                    Subject="Error Crítico en Sistema de Órdenes"
                )

                # 5. Borrar el mensaje de la DLQ para que no se procese de nuevo
                sqs.delete_message(QueueUrl=DLQ_URL, ReceiptHandle=msg['ReceiptHandle'])
                messages_processed += 1

        conn.commit()
        cur.close()
        conn.close()
        
        return {"status": "Success", "processed": messages_processed}

    except Exception as e:
        print(f"Error en monitor de DLQ: {str(e)}")
        raise e